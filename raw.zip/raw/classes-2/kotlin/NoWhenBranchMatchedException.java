package kotlin;

/* compiled from: NoWhenBranchMatchedException.kt */
public class NoWhenBranchMatchedException extends RuntimeException {
    public NoWhenBranchMatchedException() {
    }

    public NoWhenBranchMatchedException(String str) {
        super(str);
    }
}
