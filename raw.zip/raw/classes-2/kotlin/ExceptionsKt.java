package kotlin;

/* compiled from: Exceptions.kt */
public final class ExceptionsKt extends ExceptionsKt__ExceptionsKt {
}
