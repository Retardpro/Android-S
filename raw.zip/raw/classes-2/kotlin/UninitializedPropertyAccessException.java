package kotlin;

/* compiled from: UninitializedPropertyAccessException.kt */
public final class UninitializedPropertyAccessException extends RuntimeException {
    public UninitializedPropertyAccessException() {
    }

    public UninitializedPropertyAccessException(String str) {
        super(str);
    }
}
