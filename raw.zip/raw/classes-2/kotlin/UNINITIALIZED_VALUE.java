package kotlin;

/* compiled from: Lazy.kt */
public final class UNINITIALIZED_VALUE {
    public static final UNINITIALIZED_VALUE INSTANCE = new UNINITIALIZED_VALUE();

    private UNINITIALIZED_VALUE() {
    }
}
