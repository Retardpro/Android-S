package kotlin;

public final class LazyKt extends LazyKt__LazyKt {
}
