package kotlin;

/* compiled from: TypeCastException.kt */
public class TypeCastException extends ClassCastException {
    public TypeCastException() {
    }

    public TypeCastException(String str) {
        super(str);
    }
}
