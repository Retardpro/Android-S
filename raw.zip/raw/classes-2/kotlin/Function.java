package kotlin;

/* compiled from: Function.kt */
public interface Function<R> {
}
