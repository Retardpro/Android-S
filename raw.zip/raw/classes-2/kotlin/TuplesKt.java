package kotlin;

/* compiled from: Tuples.kt */
public final class TuplesKt {
    /* renamed from: to */
    public static final <A, B> Pair<A, B> m60to(A a, B b) {
        return new Pair<>(a, b);
    }
}
