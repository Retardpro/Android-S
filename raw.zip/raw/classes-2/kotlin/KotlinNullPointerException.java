package kotlin;

/* compiled from: KotlinNullPointerException.kt */
public class KotlinNullPointerException extends NullPointerException {
    public KotlinNullPointerException() {
    }

    public KotlinNullPointerException(String str) {
        super(str);
    }
}
