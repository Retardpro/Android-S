package kotlin;

/* compiled from: ExceptionsH.kt */
public final class KotlinNothingValueException extends RuntimeException {
    public KotlinNothingValueException() {
    }

    public KotlinNothingValueException(String str) {
        super(str);
    }
}
