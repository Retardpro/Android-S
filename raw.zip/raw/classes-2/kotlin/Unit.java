package kotlin;

/* compiled from: Unit.kt */
public final class Unit {
    public static final Unit INSTANCE = new Unit();

    public String toString() {
        return "kotlin.Unit";
    }

    private Unit() {
    }
}
