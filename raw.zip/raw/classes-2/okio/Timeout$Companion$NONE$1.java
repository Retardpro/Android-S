package okio;

/* compiled from: Timeout.kt */
public final class Timeout$Companion$NONE$1 extends Timeout {
    public void throwIfReached() {
    }

    Timeout$Companion$NONE$1() {
    }
}
