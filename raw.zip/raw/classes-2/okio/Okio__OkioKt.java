package okio;

import kotlin.jvm.internal.Intrinsics;

/* compiled from: Okio.kt */
final /* synthetic */ class Okio__OkioKt {
    public static final BufferedSource buffer(Source source) {
        Intrinsics.checkNotNullParameter(source, "<this>");
        return new RealBufferedSource(source);
    }
}
